const ex=require("express")
const book=require("../models/book")
const router=ex.Router()


//creating the routers

//get all the books

router.get("/",async(req,res)=>{
  try{
    const  books= await book.find()
    res.json(books)
  }catch(err)
  {
    res.json(err)
  }
});

//get single books
router.get("/:bookId",async(req,res)=>{
const bookId=req.params.bookId

    try{
        const c=await book.findById(bookId);
        res.json(c);

    }catch(error){
        res.json(error);

    }
})

//createe books
router.post("/",async(req,res)=>{
    const book=await book.create(req.body)
    res.json(book)
})




module.exports=router;