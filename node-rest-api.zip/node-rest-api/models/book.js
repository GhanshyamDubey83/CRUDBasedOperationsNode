const mongoose=require("mongoose")

const book=mongoose.Schema({
   name:{
    type:String,
    require:true
   },
   summary:{
    type:String,
    require:true
   }

})

module.exports=mongoose.model("books",book)