const express = require("express");
const booksRouter=require("./routes/books")
const bodyParser=require('body-parser')

require("dotenv").config()
const mongoose=require('mongoose')
const app=express();

app.use(bodyParser.json)
app.use("/api/v1/books",booksRouter)



mongoose.connect(process.env.DB_CONNECTION_URL,() =>{
    console.log("connected to db:")
})

//PROCESS ENV PORT IS VARIABLE
app.listen(process.env.PORT, ()=>{
    console.log("server is running");
});